#include <iostream>

using namespace std;

int main()
{
    int arrayOfletters[6][6],x=0;
    string message;
    for(int i=1 ; i<6 ; i++)
    {
        for(int j=1 ; j<6 ; j++)
        {
            arrayOfletters[i][j]=97+x;
            x++;
        }
    }
    for(int i=0 ; i<6 ; i++)
    {
        for(int j=0 ; j<6 ; j++)
        {
            cout<<char(arrayOfletters[i][j])<<"  ";
        }
    }
    int num1, num2, num3, num4, num5;
    cout<<"enter the key : ";
    cin>>num1>>num2>>num3>>num4>>num5;
    arrayOfletters[0][1]=num1;
    arrayOfletters[1][0]=num1;
    arrayOfletters[2][0]=num2;
    arrayOfletters[0][2]=num2;
    arrayOfletters[3][0]=num3;
    arrayOfletters[0][3]=num3;
    arrayOfletters[4][0]=num4;
    arrayOfletters[0][4]=num4;
    arrayOfletters[5][0]=num5;
    arrayOfletters[0][5]=num5;
    cout<<"enter the message : ";
    cin.ignore();
    getline(cin,message);
    for(int i=0 ; i<message.length() ; i++)
    {
        for(int j=1 ; j<6 ; j++)
        {
            for(int w=1 ; w<6 ; w++)
            {
                if(char(arrayOfletters[j][w])==message[i])
                {
                    cout<<char(arrayOfletters[j])-'0'<<char(arrayOfletters[w])-'0';

                }

            }
        }
        if(message[i]==char(32))
        {
            cout<<" ";
        }
    }


    return 0;
}
