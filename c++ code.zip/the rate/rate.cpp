#include <iostream>

using namespace std;

int main()
{
    float cost , years , rate , the_rate_in_fraction , inc , x=0;
    cout<<"enter the cost of the item :";
    cin>>cost;
    cout<<endl;
    cout<<"the numbers of years from now that the item  purchased :";
    cin>>years;
    cout<<endl;
    cout<<"the rate of inflation (in percentage) :";
    cin>>rate;
    the_rate_in_fraction=(rate/100);
    while(x<years){
        inc=the_rate_in_fraction*cost;
        if (years==0.5){
            cost=cost+(0.5*inc);}
        else{
            cost=cost+inc;
        }
        years=years-1;
    }
    cout<<"the cost will be:"<<cost<<endl;

    return 0;
}
