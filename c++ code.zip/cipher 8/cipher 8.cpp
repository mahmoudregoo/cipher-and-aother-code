#include <iostream>
#include <string>
#include <bitset>
#include <cmath>
using namespace std;

int main()
{
    //number 8 in assignment:
    int num ,sum=0;
    cout<<"if you want to cipher the massege prees (1)"<<endl;
    cout<<"if you want to decipher the massege prees (2)"<<endl;
    cout<<"if you want to end prees (3)"<<endl;
    cout<<">>>";
    cin>>num;
   bitset<8> p('p');
    string word ;
    if (num==1){
    cout<<"enter the word you want to code it :";
    cin.ignore();
    getline(cin,word);
    for(int i=0 ; i<word.size() ; i++){
        int dec=word[i];
        if (word[i]==' '){
            cout<<" ";
        }
        else{
        bitset<8> x(dec);
        bitset<8> h(x^p);
        int n=7;
        for(int j=0 ; j<8 ; j++){
            sum=sum+(h[j]*(pow(2 , n)));
            n=n-1;
        }
        cout<< char (sum)<<endl;
        cout<<hex<<sum<<endl;
        }
    }
    }
    if (num==2){
            int c=0;
        cout<<"enter the the massage you want to decode it :";
        cin.ignore();
        getline(cin,word);
        int j=8;
        for(int i=0 ; i<word.size() ; i=i+8){
                if(word[i]=='a'){
                    word[i]='10';
                }
                if(word[i]=='b'){
                    word[i]='11';
                }
                if (word[i]=='c'){
                    word[i]='12';
                }
                if (word[i]=='d'){
                     word[i]='13';
                }
                if (word[i]=='e'){
                     word[i]='14';
                }
                if(word[i]=='f'){
                    word[i]='15';
                }
                int dec=word[i];
                bitset<8> x(dec);
                bitset<8> h(x^p);
                int n=7;
                for(int j=0 ; j<8 ; j++){
                    sum=sum+(h[j]*(pow(2 , n)));
                    n=n-1;
                    }
                cout<<char (sum);
        }

    }
    else{return 0;}
    return 0;
}
