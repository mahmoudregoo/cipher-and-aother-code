#include <iostream>
#include <string>
#include<cmath>
using namespace std;

int main()
{
    int n;
    cout<<"what do you want to perform"<<endl;
    cout<<"1.cipher"<<endl;
    cout<<"2. decryption \n";
    cin>>n;
    if (n==1)
    {

        int counter=0,x=0;
        string key;
        cout<<"enter the key"<<endl;
        cin>>key;
        while (key.size()!=5)
        {
            cout<<"choose another key";
            cin>>key;
        }
        for(int i=0 ; i<key.size() ; i++)
        {
            for(int j=0 ; j<key.size() ; j++)
            {
                if(key[i]==key[j])
                    counter++;
            }
            if(counter>=2)
            {
                cout<<"enter a another key : ";
                cin>>key;
                counter=0;
                i=0;
            }
            else
                counter=0;
        }
        string arr1="abcdefghijklmnopqrstuvwxyz";
        string arr2="abcdefghijklmnopqrstuvwxyz";
        string arr3[26];
        string message;
        cin.ignore();
        getline(cin,message);
        for(int i=0 ; i<5 ; i++)
        {
            arr3[i]=key[i];
        }
        for(int i=0 ; i<message.size() ; i++)
        {
            for(int j=0 ; j<26 ; j++)
            {
                if(message[i]==arr1[j])
                {
                    arr1[j]=char(35);
                }
            }
        }
        for(int i=5 ; i<26 ; i++)
        {
            if(arr1[x]!=char(35))
            {
                arr3[i]=arr1[x];
            }
            else
                i--;
            x++;
        }
        for(int i=0 ; i<message.size() ; i++)
        {
            for(int j=0 ; j<26 ; j++)
            {
                if(message[i]==arr2[j])
                    cout<<arr3[j];
            }
            if(message[i]==' ')
            {
                cout<<" ";
            }
        }
    }
    else if (n==2)
    {

        int counter=0,x=0;
        string key;
        cout<<"enter the key"<<endl;
        cin>>key;
        while (key.size()!=5)
        {
            cout<<"choose another key";
            cin>>key;
        }
        for(int i=0 ; i<key.size() ; i++)
        {
            for(int j=0 ; j<key.size() ; j++)
            {
                if(key[i]==key[j])
                    counter++;
            }
            if(counter>=2)
            {
                cout<<"enter a another key : ";
                cin>>key;
                counter=0;
                i=0;
            }
            else
                counter=0;
        }
        string arr1="abcdefghijklmnopqrstuvwxyz";
        string arr2="abcdefghijklmnopqrstuvwxyz";
        string arr3="";
        string message;
        cin.ignore();
        getline(cin,message);
        for(int i=0 ; i<5 ; i++)
        {
            arr3[i]+=key[i];
        }
        for(int i=0 ; i<message.size() ; i++)
        {
            for(int j=0 ; j<26 ; j++)
            {
                if(message[i]==arr1[j])
                {
                    arr1[j]=char(35);
                }
            }
        }
        for(int i=5 ; i<26 ; i++)
        {
            if(arr1[x]!=char(35))
            {
                arr3[i]+=arr1[x];
            }
            else
                i--;
            x++;
        }
        for(int i=0 ; i<message.size() ; i++)
        {
            for(int j=0 ; j<26 ; j++)
            {
                if(message[i]==arr3[j])
                    cout<<arr2[j];
            }
            if(message[i]==' ')
            {
                cout<<" ";
            }
        }
    }



    return 0;

}
